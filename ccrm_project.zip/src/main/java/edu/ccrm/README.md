# Campus Course & Records Manager (CCRM)

This is a starter skeleton for the CCRM project. See specification for details.
