package edu.ccrm.cli;

import edu.ccrm.config.AppConfig;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        AppConfig cfg = AppConfig.getInstance();
        System.out.println("Welcome to CCRM - data folder: " + cfg.getDataFolder());
        Scanner sc = new Scanner(System.in);
        boolean exit = false;
        while (!exit) {
            System.out.println("\nMain Menu:\n1) Manage Students\n2) Manage Courses\n3) Enrollment\n0) Exit");
            System.out.print("Choice: ");
            String line = sc.nextLine();
            switch (line) {
                case "1": System.out.println("Student menu (TODO)..."); break;
                case "2": System.out.println("Course menu (TODO)..."); break;
                case "3": System.out.println("Enrollment (TODO)..."); break;
                case "0": exit = true; break;
                default: System.out.println("Invalid option");
            }
        }
        System.out.println("Bye!");
        sc.close();
    }
}
