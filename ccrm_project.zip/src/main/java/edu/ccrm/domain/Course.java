package edu.ccrm.domain;

import java.util.Objects;

public class Course {
    private final String code;
    private final String title;
    private final int credits;
    private Instructor instructor;
    private final String department;
    private final Semester semester;

    private Course(Builder b) {
        this.code = b.code;
        this.title = b.title;
        this.credits = b.credits;
        this.instructor = b.instructor;
        this.department = b.department;
        this.semester = b.semester;
    }

    public static class Builder {
        private final String code;
        private String title = "";
        private int credits = 3;
        private Instructor instructor;
        private String department = "GEN";
        private Semester semester = Semester.FALL;

        public Builder(String code) { this.code = Objects.requireNonNull(code); }
        public Builder title(String t) { this.title = t; return this; }
        public Builder credits(int c) { this.credits = c; return this; }
        public Builder instructor(Instructor i) { this.instructor = i; return this; }
        public Builder department(String d) { this.department = d; return this; }
        public Builder semester(Semester s) { this.semester = s; return this; }
        public Course build() { return new Course(this); }
    }

    public String getCode() { return code; }
    public String getTitle() { return title; }
    public int getCredits() { return credits; }
    public Instructor getInstructor() { return instructor; }
    public void setInstructor(Instructor instructor) { this.instructor = instructor; }

    @Override
    public String toString() {
        return String.format("%s - %s (%dcr) [%s]", code, title, credits, semester);
    }
}
