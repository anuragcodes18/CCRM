package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.*;

public class Student extends Person {
    private String regNo;
    private boolean active;
    private final Map<String, Enrollment> enrollments = new HashMap<>();
    private final LocalDate dob;

    public Student(String id, String regNo, String fullName, String email, LocalDate dob) {
        super(id, fullName, email);
        this.regNo = regNo;
        this.dob = dob;
        this.active = true;
    }

    public void enroll(Enrollment e) { enrollments.put(e.getCourse().getCode(), e); }
    public void unenroll(String courseCode) { enrollments.remove(courseCode); }
    public Collection<Enrollment> getEnrollments() { return enrollments.values(); }

    public String getRegNo() { return regNo; }
    public LocalDate getDob() { return dob; }

    public String profile() {
        return String.format("Student %s (%s) - %s - active=%s", fullName, regNo, email, active);
    }
}
