package edu.ccrm.config;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;

public final class AppConfig {
    private static AppConfig instance;
    private final Path dataFolder;

    private AppConfig() {
        this.dataFolder = Paths.get(System.getProperty("user.home"), "ccrm-data");
    }

    public static synchronized AppConfig getInstance() {
        if (instance == null) instance = new AppConfig();
        return instance;
    }

    public Path getDataFolder() { return dataFolder; }
    public String getTimestamp() { return Instant.now().toString(); }
}
